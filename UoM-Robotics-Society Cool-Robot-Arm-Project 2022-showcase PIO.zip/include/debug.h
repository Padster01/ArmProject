#include <Arduino.h>

void vprint_debug(const char* fmt, va_list args);
void print_debug(const char* fmt, ...);